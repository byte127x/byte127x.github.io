from tkinter import *
from tkinter import ttk
from PIL import Image, ImageTk
from LiveLibre import splashtool, librewidgets
from LiveLibre import libreconsts as constants
import os

# Splash Screen
#s = splashtool.SplashScreen(timeout=3500, delay_after_close=1250, img='Lib/splash.png')

last_event = None
pil_image = None
orig_image = None
zoom_factor = 1

Image.open('icon.png').save('Temp/icon.ico')

class FakeEvent:
	def __init__(self):
		self.width = 1
		self.height = 1
		self.x_root = 1
		self.y_root = 1

def change_chartraits(key, value):
	character_traits[key] = value
	render_character()

def character_reposition(event):
	global last_event
	if event == None:
		event = FakeEvent()
	c.delete('all')
	c.create_image(event.width/2, event.height/2, image=view, anchor=CENTER)
	last_event = event

def render_character():
	global view, character_traits, pil_image, orig_image
	if character_traits['hair'] == 'bald':
		hair = Image.open('Lib/hair-1.png').convert('RGBA')
	elif character_traits['hair'] == 'brown-lcurled':
		hair = Image.open('Lib/hair-5.png').convert('RGBA')
	elif character_traits['hair'] == 'blondspiky':
		hair = Image.open('Lib/hair-2.png').convert('RGBA')
	elif character_traits['hair'] == 'blonde-lcurled':
		hair = Image.open('Lib/hair-3.png').convert('RGBA')
	elif character_traits['hair'] == 'blonde-scurled':
		hair = Image.open('Lib/hair-4.png').convert('RGBA')
	elif character_traits['hair'] == 'illy':
		hair = Image.open('Lib/hair-6.png').convert('RGBA')
	elif character_traits['hair'] == 'ewww':
		hair = Image.open('Lib/hair-7.png').convert('RGBA')

	if character_traits['face'] == 'happy':
		face = Image.open('Lib/face-1.png').convert('RGBA')
	elif character_traits['face'] == 'sad':
		face = Image.open('Lib/face-2.png').convert('RGBA')
	elif character_traits['face'] == 'nerv':
		face = Image.open('Lib/face-3.png').convert('RGBA')
	elif character_traits['face'] == 'worry':
		face = Image.open('Lib/face-4.png').convert('RGBA')
	elif character_traits['face'] == 'reel':
		face = Image.open('Lib/face-5.png').convert('RGBA')

	if character_traits['shirtlogo'] == 'none':
		shirt_logo = Image.open('Lib/blank.png').convert('RGBA')
	elif character_traits['shirtlogo'] == '5starbathroom':
		shirt_logo = Image.open('Lib/logo-1.png').convert('RGBA')
	elif character_traits['shirtlogo'] == 'smile':
		shirt_logo = Image.open('Lib/logo-2.png').convert('RGBA')

	if character_traits['shirt'] == 'none':
		shirt_logo = Image.open('Lib/blank.png').convert('RGBA')
		shirt = Image.open('Lib/blank.png').convert('RGBA')
	elif character_traits['shirt'] == 'pink':
		shirt = Image.open('Lib/shirt-1.png').convert('RGBA')
	elif character_traits['shirt'] == 'red':
		shirt = Image.open('Lib/shirt-2.png').convert('RGBA')
	elif character_traits['shirt'] == 'orange':
		shirt = Image.open('Lib/shirt-3.png').convert('RGBA')
	elif character_traits['shirt'] == 'green':
		shirt = Image.open('Lib/shirt-4.png').convert('RGBA')
	elif character_traits['shirt'] == 'blue':
		shirt = Image.open('Lib/shirt-5.png').convert('RGBA')
	elif character_traits['shirt'] == 'purple':
		shirt = Image.open('Lib/shirt-6.png').convert('RGBA')
	elif character_traits['shirt'] == 'rainbow':
		shirt = Image.open('Lib/shirt-7.png').convert('RGBA')
	elif character_traits['shirt'] == 'gray':
		shirt = Image.open('Lib/shirt-8.png').convert('RGBA')

	if character_traits['shorts'] == 'none':
		shorts = Image.open('Lib/blank.png').convert('RGBA')
	elif character_traits['shorts'] == 'pink':
		shorts = Image.open('Lib/shorts-1.png').convert('RGBA')
	elif character_traits['shorts'] == 'red':
		shorts = Image.open('Lib/shorts-2.png').convert('RGBA')
	elif character_traits['shorts'] == 'orange':
		shorts = Image.open('Lib/shorts-3.png').convert('RGBA')
	elif character_traits['shorts'] == 'green':
		shorts = Image.open('Lib/shorts-4.png').convert('RGBA')
	elif character_traits['shorts'] == 'blue':
		shorts = Image.open('Lib/shorts-5.png').convert('RGBA')
	elif character_traits['shorts'] == 'purple':
		shorts = Image.open('Lib/shorts-6.png').convert('RGBA')
	elif character_traits['shorts'] == 'gray':
		shorts = Image.open('Lib/shorts-7.png').convert('RGBA')

	body = Image.open('Lib/basebody.png').convert('RGBA')
	width, height = body.size

	base = Image.new(mode = "RGBA", size = (width, height),
                           color = (0, 0, 0))
	head = Image.open('Lib/hair-1.png').convert('RGBA')

	# NOTE: In future use 'base = Image.alpha_composite(img1, img2)'

	base.paste(hair, (0, 0))
	base.paste(face, (0, 0), face)
	base.paste(body, (0, 0), body)
	base.paste(shirt, (0, 0), shirt)
	base.paste(shirt_logo, (0, 0), shirt_logo)
	base.paste(shorts, (0, 0), shorts)

	pil_image = base
	orig_image = base
	zoom(zoom_factor)

def canvas_eventzoom(event):
	global zoom_factor
	# Zoom In = 1
	# Zoom Out = -1

	speed_factor = 0.125
	if zoom_factor > 0.75:
		speed_factor = 0.25

	if int(event.delta / abs(event.delta)) == 1:
		zoom_factor += speed_factor
	elif int(event.delta / abs(event.delta)) == -1:
		#zoom_factor -= 0.25
		zoom_factor -= speed_factor

	if zoom_factor > 4:
		zoom_factor -= speed_factor
		return
		
	zoom(zoom_factor)


def zoom(factor):
	global pil_image, view
	try:
		pil_image = orig_image.resize((int(orig_image.width*factor), int(orig_image.height*factor)))
	except ValueError:
		view = ImageTk.PhotoImage(pil_image)
		character_reposition(last_event)
	view = ImageTk.PhotoImage(pil_image)
	character_reposition(last_event)

def clear_shortsandshirts(*args):
	change_chartraits('shirt', 'none')
	change_chartraits('shorts', 'none')

def save_char():
	orig_image.save('Temp/character.png')

def menu_solid(event):
	solidclr_shirt_menu.tk_popup(event.x_root, event.y_root)

def menu_solidshort(event):
	solidclr_short_menu.tk_popup(event.x_root, event.y_root)

root = Tk()
root.geometry('850x400')
root.title('CharCreate')
root.iconbitmap('Temp/icon.ico')
view = ImageTk.PhotoImage(Image.open("LiveLibre/thumbinset.png"))
character_traits = {
	'face':'happy',
	'hair':'bald',
	'shirt':'none',
	'shorts':'none',
	'shirtlogo':'none',
}

# Base Frames and PanedWindow
panes = PanedWindow(root)
panes.pack(fill='both', expand=1)
left = ttk.Frame(root)
right = librewidgets.VerticalScrollbarframe(root)

panes.add(left)
panes.add(right)

# Images
noneimg = ImageTk.PhotoImage(Image.open('Lib/none.png'))
baldimg = ImageTk.PhotoImage(Image.open('Lib/hairthumb-1.png'))
blondspikyimg = ImageTk.PhotoImage(Image.open('Lib/hairthumb-2.png'))
blondcurled1img = ImageTk.PhotoImage(Image.open('Lib/hairthumb-3.png'))
blondcurled2img = ImageTk.PhotoImage(Image.open('Lib/hairthumb-4.png'))
browncurledimg = ImageTk.PhotoImage(Image.open('Lib/hairthumb-5.png'))
illyhairimg = ImageTk.PhotoImage(Image.open('Lib/hairthumb-6.png'))
elvhairimg = ImageTk.PhotoImage(Image.open('Lib/hairthumb-7.png'))
happiimg = ImageTk.PhotoImage(Image.open('Lib/facethumb-1.png'))
sadimg = ImageTk.PhotoImage(Image.open('Lib/facethumb-2.png'))
nervimg = ImageTk.PhotoImage(Image.open('Lib/facethumb-3.png'))
worriedimg = ImageTk.PhotoImage(Image.open('Lib/facethumb-4.png'))
shirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-1.png'))
pinkshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-1.png').resize((75, 56), Image.ANTIALIAS))
redshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-2.png').resize((75, 56), Image.ANTIALIAS))
orangeshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-3.png').resize((75, 56), Image.ANTIALIAS))
greenshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-4.png').resize((75, 56), Image.ANTIALIAS))
blueshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-5.png').resize((75, 56), Image.ANTIALIAS))
purpleshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-6.png').resize((75, 56), Image.ANTIALIAS))
grayshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-8.png').resize((75, 56), Image.ANTIALIAS))
shortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-1.png'))
pinkshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-1.png').resize((75, 56), Image.ANTIALIAS))
redshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-2.png').resize((75, 56), Image.ANTIALIAS))
orangeshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-3.png').resize((75, 56), Image.ANTIALIAS))
greenshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-4.png').resize((75, 56), Image.ANTIALIAS))
blueshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-5.png').resize((75, 56), Image.ANTIALIAS))
purpleshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-6.png').resize((75, 56), Image.ANTIALIAS))
grayshortimg = ImageTk.PhotoImage(Image.open('Lib/shortthumb-7.png').resize((75, 56), Image.ANTIALIAS))
rainbowshirtimg = ImageTk.PhotoImage(Image.open('Lib/shirtthumb-7.png'))
fivestarlogoimg = ImageTk.PhotoImage(Image.open('Lib/logothumb-1.png'))
smilelogoimg = ImageTk.PhotoImage(Image.open('Lib/logothumb-2.png'))

# Left Frame Content
c = Canvas(left, bg='blue')
c.pack(fill='both', expand=1)
c.bind("<MouseWheel>", canvas_eventzoom)

ttk.Button(left, text='Save', command=save_char).pack(fill=X)

# Right Frame Content
ttk.Label(right.child, text='Hair: ').pack(fill=X, padx=5)
hare_hair = librewidgets.Scrollbarframe(right.child)
hare_hair.pack(fill=X, padx=5)
ttk.Button(hare_hair.child, text='None', image=baldimg, compound='top', command=lambda: change_chartraits('hair', 'bald')).grid(row=0, column=0)
ttk.Button(hare_hair.child, text='Brown (Long Curled)', image=browncurledimg, compound='top', command=lambda: change_chartraits('hair', 'brown-lcurled')).grid(row=0, column=1)
ttk.Button(hare_hair.child, text='Blonde (Spiky)', image=blondspikyimg, compound='top', command=lambda: change_chartraits('hair', 'blondspiky')).grid(row=0, column=2)
ttk.Button(hare_hair.child, text='Blonde (Long Curled)', image=blondcurled1img, compound='top', command=lambda: change_chartraits('hair', 'blonde-lcurled')).grid(row=0, column=3)
ttk.Button(hare_hair.child, text='Blonde (Short Curled)', image=blondcurled2img, compound='top', command=lambda: change_chartraits('hair', 'blonde-scurled')).grid(row=0, column=4)
#ttk.Button(hare_hair.child, text='illymation hair', image=illyhairimg, compound='top', command=lambda: change_chartraits('hair', 'illy')).grid(row=0, column=5)
ttk.Button(hare_hair.child, text='Elvis', image=elvhairimg, compound='top', command=lambda: change_chartraits('hair', 'ewww')).grid(row=0, column=6)

ttk.Label(right.child, text='Face: ').pack(fill=X, padx=5)
poker_face = librewidgets.Scrollbarframe(right.child)
poker_face.pack(fill=X, padx=5)
ttk.Button(poker_face.child, text='Happy', image=happiimg, compound='top', command=lambda: change_chartraits('face', 'happy')).grid(row=0, column=0)
ttk.Button(poker_face.child, text='Sad', image=sadimg, compound='top', command=lambda: change_chartraits('face', 'sad')).grid(row=0, column=1)
ttk.Button(poker_face.child, text='Nervous', image=nervimg, compound='top', command=lambda: change_chartraits('face', 'nerv')).grid(row=0, column=2)
ttk.Button(poker_face.child, text='Worried', image=worriedimg, compound='top', command=lambda: change_chartraits('face', 'worry')).grid(row=0, column=3)
ttk.Button(poker_face.child, text='Realistic', image=happiimg, compound='top', command=lambda: change_chartraits('face', 'reel')).grid(row=0, column=4)

solidclr_shirt_menu = Menu(tearoff=0)
solidclr_shirt_menu.add_command(label='Pink', image=pinkshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'pink'))
solidclr_shirt_menu.add_command(label='Red', image=redshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'red'))
solidclr_shirt_menu.add_command(label='Orange', image=orangeshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'orange'))
solidclr_shirt_menu.add_command(label='Green', image=greenshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'green'))
solidclr_shirt_menu.add_command(label='Blue', image=blueshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'blue'))
solidclr_shirt_menu.add_command(label='Purple', image=purpleshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'purple'))
solidclr_shirt_menu.add_command(label='Gray', image=grayshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'gray'))

solidclr_short_menu = Menu(tearoff=0)
solidclr_short_menu.add_command(label='Pink', image=pinkshortimg, compound='top', command=lambda: change_chartraits('shorts', 'pink'))
solidclr_short_menu.add_command(label='Red', image=redshortimg, compound='top', command=lambda: change_chartraits('shorts', 'red'))
solidclr_short_menu.add_command(label='Orange', image=orangeshortimg, compound='top', command=lambda: change_chartraits('shorts', 'orange'))
solidclr_short_menu.add_command(label='Green', image=greenshortimg, compound='top', command=lambda: change_chartraits('shorts', 'green'))
solidclr_short_menu.add_command(label='Blue', image=blueshortimg, compound='top', command=lambda: change_chartraits('shorts', 'blue'))
solidclr_short_menu.add_command(label='Purple', image=purpleshortimg, compound='top', command=lambda: change_chartraits('shorts', 'purple'))
solidclr_short_menu.add_command(label='Gray', image=grayshortimg, compound='top', command=lambda: change_chartraits('shorts', 'gray'))

ttk.Label(right.child, text='Clothes: ').pack(fill=X, padx=5)
shirts = librewidgets.Scrollbarframe(right.child)
shirts.pack(fill=X, padx=5)
ttk.Button(shirts.child, text='None', image=noneimg, compound='top', command=clear_shortsandshirts).grid(row=0, column=0)

solid = ttk.Button(shirts.child, text='Shirt Color', image=shirtimg, compound='top')
solid.grid(row=0, column=1)
ttk.Button(shirts.child, text='Rainbow Shirt', image=rainbowshirtimg, compound='top', command=lambda: change_chartraits('shirt', 'rainbow')).grid(row=0, column=2)
shorts = ttk.Button(shirts.child, text='Shorts Color', image=shortimg, compound='top')
shorts.grid(row=0, column=3)

ttk.Label(right.child, text='Shirt Logo: ').pack(fill=X, padx=5)
shirt_logos = librewidgets.Scrollbarframe(right.child)
shirt_logos.pack(fill=X, padx=5)
ttk.Button(shirt_logos.child, text='None', image=noneimg, compound='top', command=lambda: change_chartraits('shirtlogo', 'none')).grid(row=0, column=0)
ttk.Button(shirt_logos.child, text='5 Star Bathroom', image=fivestarlogoimg, compound='top', command=lambda: change_chartraits('shirtlogo', '5starbathroom')).grid(row=0, column=1)
ttk.Button(shirt_logos.child, text='Smile', image=smilelogoimg, compound='top', command=lambda: change_chartraits('shirtlogo', 'smile')).grid(row=0, column=2)
#ttk.Button(shirt_logos.child, text='Sad', image=sadimg, compound='top', command=lambda: change_chartraits('face', 'sad')).grid(row=0, column=1)

render_character()

# Mainloop and Event Bindings
c.bind('<Configure>', character_reposition)
solid.bind('<Button-1>', menu_solid)
solid.bind('<Button-3>', menu_solid)
shorts.bind('<Button-1>', menu_solidshort)
shorts.bind('<Button-3>', menu_solidshort)
root.mainloop()

# After App Closes
constants.Path('Temp/').remove_all_children()
