from tkinter import *
from tkinter import ttk
from . import libreconsts
import platform

class Scrollbarframe(ttk.Frame):
	def __init__(self, parent):
		super().__init__(parent)

		self.canvas = Canvas(self, highlightthickness=0)
		self.child = ttk.Frame(self.canvas)
		self.canvas.create_window(0, 0, window=self.child)

		self.canvas.bind('<Configure>', self.update_size)
		self.canvas.after_idle(self.update_size)
		self.canvas.pack(fill='both', expand=1, side=TOP)

		self.xscr = ttk.Scrollbar(self, orient='horizontal')
		self.xscr['command'] = self.canvas.xview
		self.canvas['xscrollcommand'] = self.xscr.set
		self.xscr.pack(fill=X, side=BOTTOM)
		print(libreconsts.operating_system)

	def update_size(self, *args):
		self.canvas['scrollregion'] = self.canvas.bbox('all')
		self.canvas.config(height=self.child.winfo_height())

class VerticalScrollbarframe(ttk.Frame):
	def __init__(self, parent):
		super().__init__(parent)

		self.canvas = Canvas(self, width=2, height=2, highlightthickness=0)
		self.canvas.pack(side=LEFT, fill='both', expand=1)
		self.scr = ttk.Scrollbar(self, orient='vertical', command=self.canvas.yview)
		self.scr.pack(side=RIGHT, fill=Y)

		self.canvas['yscrollcommand'] = self.scr.set
		self.canvas.bind('<Configure>', self.config)

		self.child = ttk.Frame(self.canvas)
		self.canvas_frame = self.canvas.create_window((0, 0), window=self.child, anchor=NW)

	def config(self, event):
		self.canvas.configure(scrollregion=self.canvas.bbox('all'))
		#if event.width > self.child.winfo_width():
		self.canvas.itemconfig(self.canvas_frame, width=event.width-4)