from tkinter import *
from PIL import Image, ImageTk
import time

class SplashScreen(Tk):
	def __init__(self, timeout=5000, img='LiveLibre/thumb.png', delay_after_close=500):
		super().__init__()
		if img != 'LiveLibre/thumb.png':
			img = Image.open('LiveLibre/thumbinset.png')
			background = Image.open('Lib\\splash.png')
			img_w, img_h = img.size
			bg_w, bg_h = background.size
			offset = ((bg_w - img_w), (bg_h - img_h))
			#img.putalpha(128)
			background.paste(img, offset, img)
			self.img = ImageTk.PhotoImage(background)
		else:
			self.img = ImageTk.PhotoImage(Image.open(img))
		Label(self, image=self.img, bd=0).pack()
		self.eval('tk::PlaceWindow . center')
		self.delay_after_close = delay_after_close
		self.overrideredirect(True)
		self.after(5000, self.close)
		self.mainloop()

	def close(self, *args):
		self.destroy()
		time.sleep(self.delay_after_close/1000)