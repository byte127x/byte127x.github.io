import platform, time, os

operating_system = platform.system()
if operating_system == 'Darwin':
	operating_system = 'MacOS'

NoneType = type(None)

class LibreConstantType: pass

class Path(LibreConstantType):
	def __init__(self, path):
		super().__init__()
		self.raw = path

	def rawpath(self):
		return self.raw

	def remove_all_children(self, exceptions=None):
		if not ((type(exceptions) == NoneType) or (type(exceptions) == list) or (type(exceptions) == tuple)):
			raise TypeError('Parameter \'exceptions\' must be a tuple, list, or None')
		if exceptions == None:
			exceptions = []
		for f in os.listdir(self.raw):
			if f in exceptions:
				continue
			print(f)
			os.remove(os.path.join(self.raw, f))

class RandomNumber(LibreConstantType):
	def __init__(self, rng_type='libre-middlesquarecomplex', seed=None):
		if seed == None:
			seed = int(time.time())

		if rng_type == 'libre-middlesquarecomplex':
			self.numerical_value = self.libre_middlesquarecomplex(seed)


	def libre_middlesquarecomplex(self, seed):
		large_num = int(self.sqr(self.sqr(self.sqr(self.sqr(self.sqr(seed))))))
		large_num = large_num**3
		return large_num

	def sqr(self, seed):
		squared = seed**2
		string_seed = str(squared)
		try:
			return int(string_seed[-10:len(string_seed)][0:-5])
		except ValueError:
			return int(string_seed[-10:len(string_seed)])

	def value(self):
		return self.numerical_value